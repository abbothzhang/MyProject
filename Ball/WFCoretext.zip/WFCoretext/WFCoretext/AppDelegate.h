//
//  AppDelegate.h
//  WFCoretext
//
//  Created by 阿虎 on 14/10/24.
//  Copyright (c) 2014年 tigerwf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

