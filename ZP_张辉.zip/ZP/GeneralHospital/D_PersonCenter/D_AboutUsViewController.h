//
//  D_AboutUsViewController.h
//  GeneralHospital
//
//  Created by 夏科杰 on 15/2/4.
//  Copyright (c) 2015年 夏科杰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface D_AboutUsViewController : UcmedViewStyle

@end
