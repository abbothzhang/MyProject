//
//  GlobalHead.h
//  GeneralHospital
//
//  Created by 夏科杰 on 14-8-21.
//  Copyright (c) 2014年 夏科杰. All rights reserved.
//
//#define APPID        @"hzpt_iphone"
//#define APPKEY       @"ZW5sNWVWOXBjR2h2Ym1VPQ=="

#import <CoreLocation/CoreLocation.h>
#import <Foundation/Foundation.h>
#import "RTSpinKitView.h"

NSMutableDictionary    *G_ShopCar;
RTSpinKitView          *UPLayerView;
NSMutableDictionary    *G_UseDict;
CLLocationCoordinate2D Location;
NSMutableDictionary    *G_PersonDetail;


















