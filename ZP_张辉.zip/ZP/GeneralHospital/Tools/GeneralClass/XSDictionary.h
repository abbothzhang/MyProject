//
//  XSDictionary.h
//  GeneralHospital
//
//  Created by 夏科杰 on 14-7-2.
//  Copyright (c) 2014年 夏科杰. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary(NSDictionary)
- (id  )ObjectForKey:(id)aKey;
@end
