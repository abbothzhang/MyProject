//
//  B_AppointDetailViewController.h
//  zhipin
//
//  Created by kjx on 15/4/4.
//  Copyright (c) 2015年 夏科杰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface B_AppointDetailViewController :  UcmedViewStyle
{
    NSDictionary *ResultDict;
}
@property(nonatomic,retain)NSString *OrderId;
@end
