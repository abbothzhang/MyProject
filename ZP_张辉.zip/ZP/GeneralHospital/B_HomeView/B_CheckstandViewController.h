//
//  B_CheckstandViewController.h
//  GeneralHospital
//
//  Created by 夏科杰 on 15/1/25.
//  Copyright (c) 2015年 夏科杰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface B_CheckstandViewController : UcmedViewStyle
@property(nonatomic,retain)NSDictionary *SellDict;
@property(nonatomic,retain)NSString     *AllPrice;
@property(nonatomic,assign)int          Tag;
@end
