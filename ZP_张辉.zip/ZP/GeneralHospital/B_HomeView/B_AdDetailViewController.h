//
//  B_AdDetailViewController.h
//  zhipin
//
//  Created by IOS开发 on 15/7/4.
//  Copyright (c) 2015年 夏科杰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface B_AdDetailViewController : UIViewController

@end
