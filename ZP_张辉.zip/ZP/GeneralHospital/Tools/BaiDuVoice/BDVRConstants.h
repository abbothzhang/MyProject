//
//  BDVRConstants.h
//  BDVRClientSample
//
//  Created by  段弘 on 13-10-28.
//
//

#define BDVR_DEFAULT_SEARCH_PRODUCT_ID @"1"
#define BDVR_DEFAULT_INPUT_PRODUCT_ID @"512"
#define BDVR_QUNAR_PRODUCT_ID @"256"
#define BDVR_USE_SDK_DEFAULT_PRODUCT_ID @"-1"
