//
//  D_ImageViewController.h
//  GeneralHospital
//
//  Created by 夏科杰 on 14-9-30.
//  Copyright (c) 2014年 夏科杰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface D_ImageViewController : UcmedViewStyle
@property(nonatomic,retain)NSString *ImageName;
@end
