//
//  XSArray.h
//  GeneralHospital
//
//  Created by 夏科杰 on 14-7-2.
//  Copyright (c) 2014年 夏科杰. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray(NSArray)
- (id)ObjectAtIndex:(NSUInteger)index;
@end
